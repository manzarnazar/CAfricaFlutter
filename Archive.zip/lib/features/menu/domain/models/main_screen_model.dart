import 'package:flutter/material.dart';

class MainScreenModel{
  final Widget screen;
  final String title;
  final String icon;
  MainScreenModel(this.screen, this.title, this.icon);
}