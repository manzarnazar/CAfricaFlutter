enum FooterType {
  sliver,
  nonSliver,
}