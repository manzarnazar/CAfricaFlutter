enum HtmlType {
  termsAndCondition,
  aboutUs,
  privacyPolicy,
  faq,
  cancellationPolicy,
  refundPolicy,
  returnPolicy,
}